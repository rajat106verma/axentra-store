// src/components/Profile.js
import React from 'react';

const Profile = () => (
  <div className="container mt-4">
    <h2>Your Profile</h2>
    <p>Manage your account, returns, and cancellations here.</p>
  </div>
);

export default Profile;
